export interface Subscription {
    [key: string]: any;
}