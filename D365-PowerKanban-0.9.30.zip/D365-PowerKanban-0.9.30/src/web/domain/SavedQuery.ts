export interface SavedQuery {
    fetchxml: string;
    layoutxml: string;
    name: string;
    savedqueryid: string;
}