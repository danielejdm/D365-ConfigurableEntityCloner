export const ItemTypes = {
    Tile: "tile",
    Lane: "lane"
};