import { Option } from "./Metadata";

export interface BoardLane {
    option: Option;
    data: Array<any>;
}